@echo off
setlocal
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "scripts\bootstrap_ollama.ps1" -EnsureModel
if errorlevel 1 (
  echo Failed to bootstrap local Ollama runtime.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Run Jarvas-Install-and-Run.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python jarvas_desktop.py
