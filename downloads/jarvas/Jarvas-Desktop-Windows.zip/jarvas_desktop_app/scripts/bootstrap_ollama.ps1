param(
  [switch]$EnsureModel
)

$ErrorActionPreference = 'Stop'
$AppDir = Split-Path -Parent $PSScriptRoot

$DefaultSharedRoot = if ($env:LOCALAPPDATA) {
  Join-Path $env:LOCALAPPDATA 'JarvasDesktopShared'
} elseif ($env:USERPROFILE) {
  Join-Path $env:USERPROFILE 'AppData\Local\JarvasDesktopShared'
} else {
  Join-Path $AppDir 'shared_cache'
}

$SharedRoot = if ($env:JARVAS_SHARED_HOME) { $env:JARVAS_SHARED_HOME } else { $DefaultSharedRoot }
$BundleDir = Join-Path $SharedRoot 'ollama_bundle'
$ZipPath = Join-Path $BundleDir 'ollama-windows-amd64.zip'
$OllamaDir = Join-Path $SharedRoot 'ollama-runtime'
$ModelsDir = Join-Path $SharedRoot 'models'
$DownloadUrl = 'https://github.com/ollama/ollama/releases/download/v0.19.0/ollama-windows-amd64.zip'
$HealthUrl = 'http://127.0.0.1:11435/api/tags'
$DefaultModel = 'llama3.2:1b'
$PidPath = Join-Path $AppDir 'ollama.pid'

New-Item -ItemType Directory -Force -Path $SharedRoot | Out-Null
New-Item -ItemType Directory -Force -Path $BundleDir | Out-Null
New-Item -ItemType Directory -Force -Path $ModelsDir | Out-Null

Add-Type -AssemblyName System.IO.Compression.FileSystem

$script:LoaderEnabled = $false
$script:LoaderForm = $null
$script:LoaderTitle = $null
$script:LoaderStatus = $null
$script:LoaderDetail = $null
$script:LoaderBar = $null
$script:LoaderPercent = $null

function Show-Loader {
  try {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing

    $form = New-Object System.Windows.Forms.Form
    $form.Text = 'Jarvas Loading'
    $form.Width = 560
    $form.Height = 210
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.StartPosition = 'CenterScreen'
    $form.BackColor = [System.Drawing.Color]::FromArgb(6, 12, 16)
    $form.ForeColor = [System.Drawing.Color]::FromArgb(237, 247, 248)
    $form.TopMost = $true

    $title = New-Object System.Windows.Forms.Label
    $title.Left = 24
    $title.Top = 20
    $title.Width = 500
    $title.Height = 30
    $title.Font = New-Object System.Drawing.Font('Segoe UI', 16, [System.Drawing.FontStyle]::Bold)
    $title.Text = 'Jarvas is loading'
    $title.ForeColor = [System.Drawing.Color]::FromArgb(237, 247, 248)
    $title.BackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($title)

    $status = New-Object System.Windows.Forms.Label
    $status.Left = 24
    $status.Top = 62
    $status.Width = 500
    $status.Height = 24
    $status.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $status.Text = 'Preparing shared runtime...'
    $status.ForeColor = [System.Drawing.Color]::FromArgb(159, 184, 191)
    $status.BackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($status)

    $detail = New-Object System.Windows.Forms.Label
    $detail.Left = 24
    $detail.Top = 88
    $detail.Width = 500
    $detail.Height = 22
    $detail.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $detail.Text = ''
    $detail.ForeColor = [System.Drawing.Color]::FromArgb(124, 242, 239)
    $detail.BackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($detail)

    $bar = New-Object System.Windows.Forms.ProgressBar
    $bar.Left = 24
    $bar.Top = 122
    $bar.Width = 420
    $bar.Height = 22
    $bar.Minimum = 0
    $bar.Maximum = 100
    $bar.Value = 0
    $form.Controls.Add($bar)

    $percent = New-Object System.Windows.Forms.Label
    $percent.Left = 456
    $percent.Top = 118
    $percent.Width = 68
    $percent.Height = 28
    $percent.Font = New-Object System.Drawing.Font('Segoe UI', 12, [System.Drawing.FontStyle]::Bold)
    $percent.TextAlign = 'MiddleRight'
    $percent.Text = '0%'
    $percent.ForeColor = [System.Drawing.Color]::FromArgb(124, 242, 239)
    $percent.BackColor = [System.Drawing.Color]::Transparent
    $form.Controls.Add($percent)

    $form.Show()
    [System.Windows.Forms.Application]::DoEvents()

    $script:LoaderForm = $form
    $script:LoaderTitle = $title
    $script:LoaderStatus = $status
    $script:LoaderDetail = $detail
    $script:LoaderBar = $bar
    $script:LoaderPercent = $percent
    $script:LoaderEnabled = $true
  } catch {
    $script:LoaderEnabled = $false
  }
}

function Update-Loader {
  param(
    [int]$Percent,
    [string]$Status,
    [string]$Detail = ''
  )

  $Percent = [Math]::Max(0, [Math]::Min(100, $Percent))
  Write-Host ("[{0,3}%] {1}" -f $Percent, $Status) -ForegroundColor DarkCyan
  if ($Detail) {
    Write-Host "       $Detail" -ForegroundColor DarkGray
  }

  if (-not $script:LoaderEnabled -or -not $script:LoaderForm) {
    return
  }

  try {
    $script:LoaderStatus.Text = $Status
    $script:LoaderDetail.Text = $Detail
    $script:LoaderBar.Value = $Percent
    $script:LoaderPercent.Text = "$Percent%"
    [System.Windows.Forms.Application]::DoEvents()
  } catch {
    # ignore loader repaint failures
  }
}

function Close-Loader {
  if (-not $script:LoaderEnabled -or -not $script:LoaderForm) {
    return
  }
  try {
    $script:LoaderForm.Close()
    $script:LoaderForm.Dispose()
  } catch {
    # ignore close failures
  } finally {
    $script:LoaderEnabled = $false
    $script:LoaderForm = $null
  }
}

function Map-StagePercent {
  param(
    [double]$LocalPercent,
    [int]$StageStart,
    [int]$StageEnd
  )

  $clamped = [Math]::Max(0.0, [Math]::Min(100.0, $LocalPercent))
  return [int][Math]::Round($StageStart + (($StageEnd - $StageStart) * ($clamped / 100.0)))
}

function Format-MB {
  param([double]$Bytes)
  return ('{0:N1} MB' -f ($Bytes / 1MB))
}

function Test-OllamaHealthy {
  try {
    $resp = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 2
    return $resp.StatusCode -eq 200
  } catch {
    return $false
  }
}

function Wait-OllamaHealthy {
  param([int]$Seconds = 30)
  $deadline = (Get-Date).AddSeconds($Seconds)
  while((Get-Date) -lt $deadline) {
    if (Test-OllamaHealthy) { return $true }
    Start-Sleep -Milliseconds 500
  }
  return $false
}

function Test-ZipArchive {
  param([string]$Path)
  if (-not (Test-Path $Path)) { return $false }
  try {
    $zip = [System.IO.Compression.ZipFile]::OpenRead($Path)
    $null = $zip.Entries.Count
    $zip.Dispose()
    return $true
  } catch {
    return $false
  }
}

function Download-FileWithProgress {
  param(
    [string]$Url,
    [string]$Path,
    [int]$StageStart = 5,
    [int]$StageEnd = 45
  )

  $request = [System.Net.HttpWebRequest]::Create($Url)
  $request.UserAgent = 'Jarvas Desktop Installer'
  $response = $request.GetResponse()
  $responseStream = $response.GetResponseStream()
  $contentLength = [int64]$response.ContentLength
  $buffer = New-Object byte[] 1048576
  $received = [int64]0

  $targetDir = Split-Path -Parent $Path
  if ($targetDir) {
    New-Item -ItemType Directory -Force -Path $targetDir | Out-Null
  }

  $fileStream = [System.IO.File]::Open($Path, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
  try {
    Update-Loader -Percent $StageStart -Status 'Downloading official Ollama runtime...' -Detail 'Connecting...'
    while (($read = $responseStream.Read($buffer, 0, $buffer.Length)) -gt 0) {
      $fileStream.Write($buffer, 0, $read)
      $received += $read

      if ($contentLength -gt 0) {
        $local = [Math]::Round(($received / $contentLength) * 100.0, 0)
        $global = Map-StagePercent -LocalPercent $local -StageStart $StageStart -StageEnd $StageEnd
        Update-Loader -Percent $global -Status 'Downloading official Ollama runtime...' -Detail ("{0} of {1}" -f (Format-MB $received), (Format-MB $contentLength))
      } else {
        Update-Loader -Percent $StageStart -Status 'Downloading official Ollama runtime...' -Detail ("{0} downloaded" -f (Format-MB $received))
      }
    }
    Update-Loader -Percent $StageEnd -Status 'Download complete.' -Detail ("Saved to {0}" -f $Path)
  } finally {
    if ($fileStream) { $fileStream.Dispose() }
    if ($responseStream) { $responseStream.Dispose() }
    if ($response) { $response.Dispose() }
  }
}

function Download-OllamaZip {
  param([string]$Path)
  Write-Host 'Downloading official Ollama standalone zip into shared cache...' -ForegroundColor Cyan
  Download-FileWithProgress -Url $DownloadUrl -Path $Path -StageStart 5 -StageEnd 45
  if (-not (Test-ZipArchive $Path)) {
    throw 'Downloaded Ollama zip is invalid or incomplete.'
  }
}

function Ensure-OllamaZip {
  param([string]$Path)
  if (Test-ZipArchive $Path) {
    Update-Loader -Percent 45 -Status 'Reusing shared Ollama zip cache...' -Detail $Path
    Write-Host 'Reusing shared Ollama zip cache...' -ForegroundColor DarkCyan
    return
  }

  if (Test-Path $Path) {
    Update-Loader -Percent 5 -Status 'Cached Ollama zip was invalid.' -Detail 'Removing incomplete archive and downloading a fresh copy...'
    Write-Host 'Cached Ollama zip is corrupted or incomplete. Removing it and downloading a fresh copy...' -ForegroundColor Yellow
    Remove-Item -Force $Path
  }

  Download-OllamaZip -Path $Path
}

function Expand-ZipWithProgress {
  param(
    [string]$ArchivePath,
    [string]$DestinationPath,
    [int]$StageStart = 45,
    [int]$StageEnd = 70
  )

  if (Test-Path $DestinationPath) {
    Remove-Item -Recurse -Force $DestinationPath
  }
  New-Item -ItemType Directory -Force -Path $DestinationPath | Out-Null

  $zip = [System.IO.Compression.ZipFile]::OpenRead($ArchivePath)
  $buffer = New-Object byte[] 1048576
  $totalBytes = [int64](($zip.Entries | Measure-Object -Property Length -Sum).Sum)
  if ($totalBytes -le 0) { $totalBytes = 1 }
  $processed = [int64]0

  try {
    Update-Loader -Percent $StageStart -Status 'Extracting shared Ollama runtime...' -Detail 'Preparing files...'

    foreach ($entry in $zip.Entries) {
      $destinationFile = Join-Path $DestinationPath $entry.FullName

      if ([string]::IsNullOrEmpty($entry.Name)) {
        New-Item -ItemType Directory -Force -Path $destinationFile | Out-Null
        continue
      }

      $destinationDir = Split-Path -Parent $destinationFile
      if ($destinationDir) {
        New-Item -ItemType Directory -Force -Path $destinationDir | Out-Null
      }

      $input = $entry.Open()
      $output = [System.IO.File]::Open($destinationFile, [System.IO.FileMode]::Create, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
      try {
        while (($read = $input.Read($buffer, 0, $buffer.Length)) -gt 0) {
          $output.Write($buffer, 0, $read)
          $processed += $read
          $local = [Math]::Round(($processed / $totalBytes) * 100.0, 0)
          $global = Map-StagePercent -LocalPercent $local -StageStart $StageStart -StageEnd $StageEnd
          Update-Loader -Percent $global -Status 'Extracting shared Ollama runtime...' -Detail $entry.FullName
        }
      } finally {
        if ($output) { $output.Dispose() }
        if ($input) { $input.Dispose() }
      }

      try {
        if ($entry.LastWriteTime -and (Test-Path $destinationFile)) {
          [System.IO.File]::SetLastWriteTime($destinationFile, $entry.LastWriteTime.DateTime)
        }
      } catch {
        # timestamp set is best-effort only
      }
    }

    Update-Loader -Percent $StageEnd -Status 'Runtime extraction complete.' -Detail $DestinationPath
  } finally {
    if ($zip) { $zip.Dispose() }
  }
}

function Expand-OllamaZip {
  param(
    [string]$ArchivePath,
    [string]$DestinationPath
  )

  try {
    Write-Host 'Extracting shared Ollama runtime...' -ForegroundColor Cyan
    Expand-ZipWithProgress -ArchivePath $ArchivePath -DestinationPath $DestinationPath -StageStart 45 -StageEnd 70
  } catch {
    Update-Loader -Percent 45 -Status 'Extraction failed. Retrying with a fresh download...' -Detail $_.Exception.Message
    Write-Host 'Ollama runtime archive extraction failed. Deleting cached zip and retrying once...' -ForegroundColor Yellow
    if (Test-Path $ArchivePath) { Remove-Item -Force $ArchivePath }
    Download-OllamaZip -Path $ArchivePath
    Write-Host 'Retrying Ollama runtime extraction...' -ForegroundColor Cyan
    Expand-ZipWithProgress -ArchivePath $ArchivePath -DestinationPath $DestinationPath -StageStart 45 -StageEnd 70
  }
}

function Get-InstalledModels {
  try {
    $resp = Invoke-WebRequest -Uri $HealthUrl -UseBasicParsing -TimeoutSec 5
    $data = $resp.Content | ConvertFrom-Json
    return @($data.models | ForEach-Object { $_.name })
  } catch {
    return @()
  }
}

function Test-ModelInstalled {
  param([string]$ModelName)
  $models = Get-InstalledModels
  return @($models | Where-Object { $_ -eq $ModelName }).Count -gt 0
}

function Pull-ModelWithProgress {
  param(
    [string]$ModelName,
    [int]$StageStart = 80,
    [int]$StageEnd = 100
  )

  $payload = @{ name = $ModelName; stream = $true } | ConvertTo-Json -Compress
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($payload)
  $request = [System.Net.HttpWebRequest]::Create('http://127.0.0.1:11435/api/pull')
  $request.Method = 'POST'
  $request.ContentType = 'application/json'
  $request.ContentLength = $bytes.Length
  $request.Timeout = -1
  $request.ReadWriteTimeout = -1

  $requestStream = $request.GetRequestStream()
  try {
    $requestStream.Write($bytes, 0, $bytes.Length)
  } finally {
    $requestStream.Dispose()
  }

  $response = $request.GetResponse()
  $stream = $response.GetResponseStream()
  $reader = New-Object System.IO.StreamReader($stream)
  $lastPercent = $StageStart

  try {
    Update-Loader -Percent $StageStart -Status ("Downloading default model {0}..." -f $ModelName) -Detail 'Connecting to local Ollama...'
    while (-not $reader.EndOfStream) {
      $line = $reader.ReadLine()
      if ([string]::IsNullOrWhiteSpace($line)) { continue }

      try {
        $event = $line | ConvertFrom-Json
      } catch {
        continue
      }

      $status = if ($event.status) { [string]$event.status } else { "Downloading default model $ModelName..." }
      $detail = ''

      if ($null -ne $event.total -and [double]$event.total -gt 0 -and $null -ne $event.completed) {
        $local = [Math]::Round((([double]$event.completed / [double]$event.total) * 100.0), 0)
        $lastPercent = Map-StagePercent -LocalPercent $local -StageStart $StageStart -StageEnd $StageEnd
        $detail = ("{0} of {1}" -f (Format-MB ([double]$event.completed)), (Format-MB ([double]$event.total)))
      }

      Update-Loader -Percent $lastPercent -Status $status -Detail $detail
    }

    Update-Loader -Percent $StageEnd -Status ("Default model ready: {0}" -f $ModelName) -Detail 'Jarvas can launch now.'
  } finally {
    if ($reader) { $reader.Dispose() }
    if ($stream) { $stream.Dispose() }
    if ($response) { $response.Dispose() }
  }
}

try {
  Show-Loader
  Update-Loader -Percent 2 -Status 'Preparing shared runtime...' -Detail $SharedRoot

  if (-not (Test-Path (Join-Path $OllamaDir 'ollama.exe'))) {
    Ensure-OllamaZip -Path $ZipPath
    Expand-OllamaZip -ArchivePath $ZipPath -DestinationPath $OllamaDir
  } else {
    Update-Loader -Percent 70 -Status 'Reusing shared Ollama runtime...' -Detail $OllamaDir
  }

  $env:OLLAMA_HOST = '127.0.0.1:11435'
  $env:OLLAMA_MODELS = $ModelsDir
  $servePath = Join-Path $OllamaDir 'ollama.exe'

  if (-not (Test-OllamaHealthy)) {
    Update-Loader -Percent 72 -Status 'Starting shared local Ollama...' -Detail 'Waiting for the local AI runtime to come online...'
    Write-Host 'Starting shared local Ollama on 127.0.0.1:11435...' -ForegroundColor Cyan
    $proc = Start-Process -FilePath $servePath -ArgumentList 'serve' -WorkingDirectory $OllamaDir -PassThru -WindowStyle Hidden
    Set-Content -Path $PidPath -Value $proc.Id -Encoding ascii

    $startupSeconds = 40
    $ready = $false
    for ($i = 0; $i -lt $startupSeconds * 2; $i++) {
      if (Test-OllamaHealthy) {
        $ready = $true
        break
      }
      $local = [Math]::Round((($i + 1) / ($startupSeconds * 2)) * 100.0, 0)
      $global = Map-StagePercent -LocalPercent $local -StageStart 72 -StageEnd 80
      Update-Loader -Percent $global -Status 'Starting shared local Ollama...' -Detail 'Waiting for health check...'
      Start-Sleep -Milliseconds 500
    }

    if (-not $ready) {
      throw 'Ollama did not become ready on 127.0.0.1:11435.'
    }
    Update-Loader -Percent 80 -Status 'Local Ollama runtime is ready.' -Detail 'Health check passed.'
  } else {
    Update-Loader -Percent 80 -Status 'Shared local Ollama already running.' -Detail 'Reusing existing runtime.'
    Write-Host 'Shared local Ollama already running. Reusing it.' -ForegroundColor DarkCyan
  }

  if ($EnsureModel) {
    if (-not (Test-ModelInstalled -ModelName $DefaultModel)) {
      Write-Host "No shared local model found. Pulling default Jarvas model $DefaultModel ..." -ForegroundColor Cyan
      Pull-ModelWithProgress -ModelName $DefaultModel -StageStart 80 -StageEnd 100
    } else {
      Update-Loader -Percent 100 -Status ("Reusing shared local model cache: {0}" -f $DefaultModel) -Detail $ModelsDir
      Write-Host "Reusing shared local model cache: $DefaultModel" -ForegroundColor DarkCyan
    }
  } else {
    Update-Loader -Percent 100 -Status 'Bootstrap complete.' -Detail 'Jarvas is ready.'
  }

  Start-Sleep -Milliseconds 500
} catch {
  Update-Loader -Percent 100 -Status 'Bootstrap failed.' -Detail $_.Exception.Message
  throw
} finally {
  Close-Loader
}
