@echo off
setlocal
cd /d "%~dp0"
if exist "ollama.pid" (
  set /p OLLAMA_PID=<"ollama.pid"
  if not "%OLLAMA_PID%"=="" (
    powershell -NoProfile -Command "try { Stop-Process -Id %OLLAMA_PID% -Force -ErrorAction Stop; Write-Host 'Stopped shared local Ollama.' -ForegroundColor Cyan } catch { Write-Host 'Shared Ollama was not running from this PID file.' -ForegroundColor Yellow }"
  )
  del /q "ollama.pid" >nul 2>nul
) else (
  echo No local PID file found in this Jarvas copy.
  echo If Ollama is still running from another Jarvas copy, stop it from that copy or end ollama.exe manually.
)
