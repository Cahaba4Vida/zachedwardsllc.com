@echo off
setlocal
cd /d "%~dp0"
call ".venv\Scripts\activate.bat" 2>nul
where pyinstaller >nul 2>nul
if errorlevel 1 (
  echo PyInstaller is not installed in this environment.
  echo Run: .venv\Scripts\python -m pip install pyinstaller
  pause
  exit /b 1
)

pyinstaller --noconfirm --windowed --onefile --icon "assets\jarvas.ico" --name "JarvasDesktop" jarvas_desktop.py
echo Done. Check the dist folder.
pause
