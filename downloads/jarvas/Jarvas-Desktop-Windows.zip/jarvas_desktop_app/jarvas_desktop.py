
import base64
import io
import json
import os
import queue
import re
import tempfile
import threading
import time
import zipfile
import webbrowser
from pathlib import Path
from tkinter import Tk, Frame, Label, Button, Text, Canvas, Scrollbar, Listbox, END, LEFT, RIGHT, Y, BOTH, X, VERTICAL, HORIZONTAL, filedialog, messagebox, StringVar
from tkinter import ttk
from tkinter.scrolledtext import ScrolledText

import requests
from PIL import Image, ImageTk

APP_NAME = "Jarvas Desktop"
APP_DIR = Path(__file__).resolve().parent
ASSETS_DIR = APP_DIR / "assets"
STATE_PATH = APP_DIR / "jarvas_state.json"
OLLAMA_API = "http://127.0.0.1:11435/api"
VISION_MODEL_PATTERNS = [
    r"gemma3", r"gemma3n", r"qwen2\.5vl", r"llama3\.2-vision",
    r"llava", r"bakllava", r"minicpm-v", r"moondream", r"vision"
]
CODE_MODEL_PATTERNS = [r"coder", r"codestral", r"deepseek-coder", r"starcoder", r"codegemma", r"qwen.*coder"]
SMALL_MODEL_HINTS = [r"0\.5b", r"1b", r"1\.1b", r"1\.5b", r"2b", r"mini", r"small"]
GENERAL_HINTS = [r"llama", r"qwen", r"gemma", r"mistral", r"phi"]
JARVAS_VERSIONS = ["Jarvas Instant", "Jarvas", "Jarvas Coding", "Jarvas Strategy", "Jarvas Images"]

THEME = {
    "bg": "#03080b",
    "panel": "#071117",
    "panel2": "#0b151d",
    "line": "#12303b",
    "text": "#edf7f8",
    "muted": "#9fb8bf",
    "accent": "#46d6d6",
    "accent2": "#7cf2ef",
    "user": "#10313a",
    "assistant": "#081116",
    "error": "#ff7b7b",
}

def safe_json_load(path, fallback):
    try:
        return json.loads(Path(path).read_text("utf-8"))
    except Exception:
        return fallback

def is_vision_model(name: str) -> bool:
    low = (name or "").lower()
    return any(re.search(p, low) for p in VISION_MODEL_PATTERNS)

def model_size_score(name: str) -> float:
    low = (name or "").lower()
    m = re.search(r'(\d+(?:\.\d+)?)b', low)
    if m:
        return float(m.group(1))
    if "mini" in low or "small" in low:
        return 2.0
    return 999.0

def version_rank(version: str, model_name: str) -> tuple:
    low = (model_name or "").lower()
    size = model_size_score(low)
    is_vision = is_vision_model(low)
    is_code = any(re.search(p, low) for p in CODE_MODEL_PATTERNS)
    has_general = any(h in low for h in ["llama", "qwen", "gemma", "mistral", "phi"])
    if version == "Jarvas Images":
        return (0 if is_vision else 1, size)
    if version == "Jarvas Coding":
        return (0 if is_code else 1, size)
    if version == "Jarvas Instant":
        return (0 if size <= 2.1 else 1, size)
    if version == "Jarvas":
        return (0 if has_general and not is_vision else 1, abs(size - 3.0))
    if version == "Jarvas Strategy":
        return (0 if has_general and not is_vision else 1, abs(size - 7.0))
    return (9, size)

def map_models_to_versions(models):
    mapping = {}
    for version in JARVAS_VERSIONS:
        sorted_models = sorted(models, key=lambda m: version_rank(version, m))
        mapping[version] = sorted_models[0] if sorted_models else ""
    return mapping

def parse_code_blocks(text: str):
    pattern = re.compile(r"```([^\n`]*)\n(.*?)```", re.S)
    blocks = []
    for fence_info, code in pattern.findall(text or ""):
        fence = fence_info.strip()
        filename = ""
        language = ""
        if fence:
            parts = fence.split()
            if parts:
                first = parts[0]
                if "." in first and not first.lower() in {"python","javascript","html","css","json","bash","ts","tsx","jsx"}:
                    filename = first
                    if len(parts) > 1:
                        language = parts[1]
                else:
                    language = first
                    if len(parts) > 1 and "." in parts[1]:
                        filename = parts[1]
        blocks.append({"filename": filename, "language": language.lower(), "content": code.strip()})
    return blocks

def default_filename_from_language(language, existing):
    lang = (language or "").lower()
    candidates = {
        "html": "index.html",
        "css": "styles.css",
        "javascript": "app.js",
        "js": "app.js",
        "python": "app.py",
        "py": "app.py",
        "json": "data.json",
        "bash": "script.sh",
        "ts": "app.ts",
        "tsx": "app.tsx",
        "jsx": "app.jsx",
    }
    base = candidates.get(lang, "notes.txt")
    if base not in existing:
        return base
    stem, ext = os.path.splitext(base)
    i = 2
    while f"{stem}_{i}{ext}" in existing:
        i += 1
    return f"{stem}_{i}{ext}"

class JarvasApp:
    def __init__(self, root):
        self.root = root
        self.root.title(APP_NAME)
        self.root.geometry("1440x920")
        self.root.minsize(1120, 760)
        self.root.configure(bg=THEME["bg"])
        try:
            self.root.iconbitmap(str(ASSETS_DIR / "jarvas.ico"))
        except Exception:
            pass

        self.state = safe_json_load(STATE_PATH, {
            "chat": [],
            "workspace": {
                "files": {
                    "index.html": "<!doctype html><html><head><meta charset='utf-8'><title>Jarvas Preview</title><link rel='stylesheet' href='styles.css'></head><body><div id='app'>Jarvas preview ready.</div><script src='app.js'></script></body></html>",
                    "styles.css": "body{font-family:Inter,Segoe UI,Arial,sans-serif;background:#081116;color:#eaf7f7;padding:24px;}#app{padding:24px;border:1px solid #12303b;border-radius:16px;background:#0b151d;}",
                    "app.js": "document.getElementById('app').insertAdjacentHTML('beforeend','<p>Build something with Jarvas Coding.</p>');",
                },
                "active_file": "index.html"
            },
            "selected_version": "Jarvas",
            "selected_model": "",
            "loaded_model": "",
            "attachments": []
        })
        self.models = []
        self.version_model_map = {}
        self.pending_queue = queue.Queue()
        self.sending = False
        self.current_response_text = ""
        self.last_assistant_text = ""
        self.last_prompt = ""
        self.attachments = []  # list of dict with path, base64, name
        self.selected_file = self.state.get("workspace", {}).get("active_file", "index.html")
        self.current_preview_temp = None
        self.auto_load_attempted = False

        self.version_var = StringVar(value=self.state.get("selected_version", "Jarvas"))
        self.model_var = StringVar(value=self.state.get("selected_model", ""))
        self.status_var = StringVar(value="Ready.")
        self.loaded_var = StringVar(value=self.state.get("loaded_model", ""))

        self._build_style()
        self._build_ui()
        self.root.after(50, self._drain_queue)
        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.refresh_models()

    def _build_style(self):
        style = ttk.Style()
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TCombobox", fieldbackground=THEME["panel2"], background=THEME["panel2"], foreground=THEME["text"], arrowcolor=THEME["accent"])
        style.configure("Treeview", background=THEME["panel2"], foreground=THEME["text"], fieldbackground=THEME["panel2"])
        style.configure("TNotebook", background=THEME["bg"], borderwidth=0)
        style.configure("TNotebook.Tab", background=THEME["panel"], foreground=THEME["muted"], padding=(14,8))
        style.map("TNotebook.Tab", background=[("selected", THEME["panel2"])], foreground=[("selected", THEME["text"])])

    def _build_ui(self):
        # background image
        self.bg_photo = None
        bg_path = ASSETS_DIR / "background.png"
        if bg_path.exists():
            try:
                img = Image.open(bg_path).convert("RGBA").resize((1600, 1000))
                img.putalpha(120)
                self.bg_photo = ImageTk.PhotoImage(img)
                bg_label = Label(self.root, image=self.bg_photo, bg=THEME["bg"])
                bg_label.place(x=0, y=0, relwidth=1, relheight=1)
            except Exception:
                pass

        top = Frame(self.root, bg=THEME["bg"])
        top.pack(fill=X, padx=18, pady=(18, 8))

        brand = Frame(top, bg=THEME["bg"])
        brand.pack(side=LEFT)
        Label(brand, text="Jarvas", fg=THEME["text"], bg=THEME["bg"], font=("Segoe UI", 24, "bold")).pack(anchor="w")
        Label(brand, text="Desktop local AI", fg=THEME["muted"], bg=THEME["bg"], font=("Segoe UI", 10)).pack(anchor="w")

        toolbar = Frame(top, bg=THEME["bg"])
        toolbar.pack(side=RIGHT)

        self.version_combo = ttk.Combobox(toolbar, textvariable=self.version_var, values=JARVAS_VERSIONS, state="readonly", width=18)
        self.version_combo.pack(side=LEFT, padx=6)
        self.version_combo.bind("<<ComboboxSelected>>", self.on_version_changed)

        self.model_combo = ttk.Combobox(toolbar, textvariable=self.model_var, values=[], width=38, state="readonly")
        self.model_combo.pack(side=LEFT, padx=6)

        self._btn(toolbar, "Refresh models", self.refresh_models).pack(side=LEFT, padx=6)
        self._btn(toolbar, "Load model", self.load_selected_model, accent=True).pack(side=LEFT, padx=6)

        self._btn(toolbar, "Clear chat", self.clear_chat).pack(side=LEFT, padx=6)

        status_frame = Frame(self.root, bg=THEME["bg"])
        status_frame.pack(fill=X, padx=18, pady=(0, 10))
        Label(status_frame, textvariable=self.status_var, fg=THEME["muted"], bg=THEME["bg"], font=("Segoe UI", 10)).pack(side=LEFT)
        Label(status_frame, textvariable=self.loaded_var, fg=THEME["accent2"], bg=THEME["bg"], font=("Segoe UI", 10, "bold")).pack(side=RIGHT)

        notebook = ttk.Notebook(self.root)
        notebook.pack(fill=BOTH, expand=True, padx=18, pady=(0, 18))

        self.chat_tab = Frame(notebook, bg=THEME["bg"])
        self.files_tab = Frame(notebook, bg=THEME["bg"])
        notebook.add(self.chat_tab, text="Chat")
        notebook.add(self.files_tab, text="Files")

        self._build_chat_tab()
        self._build_files_tab()

    def _btn(self, parent, text, command, accent=False, warn=False):
        bg = THEME["panel2"] if not accent else THEME["accent"]
        fg = THEME["text"] if not accent else "#041012"
        active = THEME["panel"] if not accent else THEME["accent2"]
        if warn:
            bg = "#431919"
            active = "#5a2020"
        return Button(parent, text=text, command=command, bg=bg, fg=fg, activebackground=active,
                      activeforeground=fg, bd=0, highlightthickness=1, highlightbackground=THEME["line"],
                      padx=14, pady=9, font=("Segoe UI", 10, "bold"), cursor="hand2")

    def _build_chat_tab(self):
        outer = Frame(self.chat_tab, bg=THEME["bg"])
        outer.pack(fill=BOTH, expand=True)

        chat_shell = Frame(outer, bg=THEME["panel"], highlightbackground=THEME["line"], highlightthickness=1)
        chat_shell.pack(fill=BOTH, expand=True, padx=0, pady=0)

        self.chat_canvas = Canvas(chat_shell, bg=THEME["panel"], highlightthickness=0)
        self.chat_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        yscroll = Scrollbar(chat_shell, orient=VERTICAL, command=self.chat_canvas.yview)
        yscroll.pack(side=RIGHT, fill=Y)
        self.chat_canvas.configure(yscrollcommand=yscroll.set)
        self.chat_inner = Frame(self.chat_canvas, bg=THEME["panel"])
        self.chat_window = self.chat_canvas.create_window((0, 0), window=self.chat_inner, anchor="nw")
        self.chat_inner.bind("<Configure>", lambda e: self._on_chat_configure())
        self.chat_canvas.bind("<Configure>", lambda e: self.chat_canvas.itemconfigure(self.chat_window, width=e.width))

        composer = Frame(self.chat_tab, bg=THEME["panel2"], highlightbackground=THEME["line"], highlightthickness=1)
        composer.pack(fill=X, pady=(12, 0))

        self.attach_strip = Frame(composer, bg=THEME["panel2"])
        self.attach_strip.pack(fill=X, padx=12, pady=(12, 0))

        row = Frame(composer, bg=THEME["panel2"])
        row.pack(fill=X, padx=12, pady=12)

        left_buttons = Frame(row, bg=THEME["panel2"])
        left_buttons.pack(side=LEFT, fill=Y)
        self._btn(left_buttons, "Attach photo", self.attach_photo).pack(pady=(0, 8))
        self._btn(left_buttons, "Continue", self.continue_reply).pack()

        self.input_text = ScrolledText(row, height=6, wrap="word", bg="#081015", fg=THEME["text"],
                                       insertbackground=THEME["accent2"], relief="flat", padx=14, pady=12,
                                       font=("Segoe UI", 12), highlightthickness=1, highlightbackground=THEME["line"])
        self.input_text.pack(side=LEFT, fill=BOTH, expand=True, padx=12)
        self.input_text.bind("<Control-Return>", lambda e: self.send_message())

        right_buttons = Frame(row, bg=THEME["panel2"])
        right_buttons.pack(side=LEFT, fill=Y)
        self._btn(right_buttons, "Send", self.send_message, accent=True).pack(pady=(0, 8))
        self._btn(right_buttons, "Use last AI code", self.use_last_ai_code).pack()

        self.render_chat()

    def _build_files_tab(self):
        root = Frame(self.files_tab, bg=THEME["bg"])
        root.pack(fill=BOTH, expand=True)

        left = Frame(root, bg=THEME["panel"], highlightbackground=THEME["line"], highlightthickness=1, width=240)
        left.pack(side=LEFT, fill=Y, padx=(0, 12))
        left.pack_propagate(False)

        Label(left, text="Project files", bg=THEME["panel"], fg=THEME["text"], font=("Segoe UI", 16, "bold")).pack(anchor="w", padx=14, pady=(14, 8))
        self.file_list = Listbox(left, bg=THEME["panel2"], fg=THEME["text"], selectbackground=THEME["accent"], selectforeground="#041012",
                                 bd=0, highlightthickness=1, highlightbackground=THEME["line"], activestyle="none", font=("Consolas", 11))
        self.file_list.pack(fill=BOTH, expand=True, padx=14, pady=(0, 12))
        self.file_list.bind("<<ListboxSelect>>", self.on_file_select)

        btns = Frame(left, bg=THEME["panel"])
        btns.pack(fill=X, padx=14, pady=(0, 14))
        self._btn(btns, "New", self.new_file).pack(side=LEFT, padx=(0, 8))
        self._btn(btns, "Rename", self.rename_file).pack(side=LEFT, padx=(0, 8))
        self._btn(btns, "Delete", self.delete_file, warn=True).pack(side=LEFT)

        right = Frame(root, bg=THEME["bg"])
        right.pack(side=LEFT, fill=BOTH, expand=True)

        header = Frame(right, bg=THEME["bg"])
        header.pack(fill=X, pady=(0, 10))
        Label(header, text="Editor", bg=THEME["bg"], fg=THEME["text"], font=("Segoe UI", 16, "bold")).pack(side=LEFT)
        self._btn(header, "Preview", self.preview_workspace).pack(side=RIGHT, padx=(8,0))
        self._btn(header, "Export ZIP", self.export_workspace, accent=True).pack(side=RIGHT)

        self.editor = ScrolledText(right, wrap="none", bg="#081015", fg=THEME["text"], insertbackground=THEME["accent2"],
                                   relief="flat", font=("Consolas", 11), padx=14, pady=14, highlightthickness=1,
                                   highlightbackground=THEME["line"])
        self.editor.pack(fill=BOTH, expand=True)
        self.editor.bind("<KeyRelease>", lambda e: self.save_editor_to_state())

        self.refresh_file_list()
        self.load_active_file()

    def _on_chat_configure(self):
        self.chat_canvas.configure(scrollregion=self.chat_canvas.bbox("all"))

    def add_chat_bubble(self, role, text, error=False):
        shell = Frame(self.chat_inner, bg=THEME["panel"])
        shell.pack(fill=X, padx=14, pady=10, anchor="e" if role == "user" else "w")

        bubble_bg = THEME["user"] if role == "user" else THEME["assistant"]
        bubble_fg = THEME["text"] if not error else THEME["error"]
        label_role = "YOU" if role == "user" else self.version_var.get().upper()

        inner = Frame(shell, bg=bubble_bg, highlightbackground=THEME["line"], highlightthickness=1)
        inner.pack(anchor="e" if role == "user" else "w", ipadx=4, ipady=4)
        Label(inner, text=label_role, bg=bubble_bg, fg=THEME["muted"], font=("Segoe UI", 9, "bold")).pack(anchor="w", padx=12, pady=(8, 4))
        txt = Label(inner, text=text, justify=LEFT, wraplength=900, bg=bubble_bg, fg=bubble_fg, font=("Segoe UI", 12))
        txt.pack(anchor="w", padx=12, pady=(0, 10))
        self.chat_canvas.update_idletasks()
        self.chat_canvas.yview_moveto(1.0)
        return txt

    def render_chat(self):
        for child in self.chat_inner.winfo_children():
            child.destroy()
        for msg in self.state.get("chat", []):
            self.add_chat_bubble(msg.get("role"), msg.get("content", ""), error=msg.get("error", False))
        self.root.after(10, lambda: self.chat_canvas.yview_moveto(1.0))

    def save_state(self):
        self.state["selected_version"] = self.version_var.get()
        self.state["selected_model"] = self.model_var.get()
        self.state["loaded_model"] = self.loaded_var.get()
        workspace = self.state.setdefault("workspace", {"files": {}, "active_file": ""})
        workspace["active_file"] = self.selected_file
        try:
            STATE_PATH.write_text(json.dumps(self.state, indent=2), "utf-8")
        except Exception:
            pass

    def on_close(self):
        self.save_editor_to_state()
        self.save_state()
        self.root.destroy()

    def refresh_models(self):
        self.status_var.set("Checking local Ollama…")
        def worker():
            try:
                res = requests.get(f"{OLLAMA_API}/tags", timeout=20)
                res.raise_for_status()
                data = res.json()
                models = [m["name"] for m in data.get("models", [])]
                self.pending_queue.put(("models", models))
            except Exception as exc:
                self.pending_queue.put(("error_status", f"Could not reach local Ollama at {OLLAMA_API}: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def on_version_changed(self, *_):
        version = self.version_var.get()
        mapped = self.version_model_map.get(version, "")
        if mapped:
            self.model_var.set(mapped)
        self.loaded_var.set(self.loaded_var.get())
        self.save_state()

    def load_selected_model(self):
        model = self.model_var.get().strip()
        if not model:
            messagebox.showwarning("No model", "Pick a local model first.")
            return
        self.status_var.set(f"Loading {model}…")
        def worker():
            try:
                payload = {
                    "model": model,
                    "prompt": "Hi",
                    "stream": False,
                    "keep_alive": "2h",
                    "options": {"num_predict": 1}
                }
                res = requests.post(f"{OLLAMA_API}/generate", json=payload, timeout=600)
                res.raise_for_status()
                self.pending_queue.put(("loaded", model))
            except Exception as exc:
                self.pending_queue.put(("error_status", f"Load failed: {exc}"))
        threading.Thread(target=worker, daemon=True).start()

    def attach_photo(self):
        paths = filedialog.askopenfilenames(title="Attach image(s)", filetypes=[("Images", "*.png;*.jpg;*.jpeg;*.webp;*.bmp")])
        if not paths:
            return
        model = self.model_var.get()
        if not is_vision_model(model):
            if not messagebox.askyesno("Text-only model", "The selected model does not look vision-capable. Attach anyway?"):
                return
        for path in paths:
            try:
                raw = Path(path).read_bytes()
                self.attachments.append({
                    "path": path,
                    "name": Path(path).name,
                    "base64": base64.b64encode(raw).decode("ascii")
                })
            except Exception as exc:
                messagebox.showerror("Attach failed", str(exc))
        self.render_attachments()

    def render_attachments(self):
        for child in self.attach_strip.winfo_children():
            child.destroy()
        if not self.attachments:
            Label(self.attach_strip, text="No attachments", bg=THEME["panel2"], fg=THEME["muted"], font=("Segoe UI", 10)).pack(anchor="w")
            return
        for att in self.attachments:
            row = Frame(self.attach_strip, bg=THEME["panel2"])
            row.pack(side=LEFT, padx=(0,8), pady=4)
            Label(row, text=att["name"], bg=THEME["panel"], fg=THEME["text"], padx=8, pady=5).pack(side=LEFT)
            Button(row, text="×", command=lambda n=att["name"]: self.remove_attachment(n), bg=THEME["panel"], fg=THEME["muted"], bd=0).pack(side=LEFT)

    def remove_attachment(self, name):
        self.attachments = [a for a in self.attachments if a["name"] != name]
        self.render_attachments()

    def clear_chat(self):
        if messagebox.askyesno("Clear chat", "Clear the current chat?"):
            self.state["chat"] = []
            self.render_chat()
            self.save_state()

    def continue_reply(self):
        if self.sending:
            return
        if not self.state.get("chat"):
            return
        self.input_text.delete("1.0", END)
        self.input_text.insert("1.0", "Continue from exactly where you stopped. Do not repeat prior content.")
        self.send_message()

    def send_message(self):
        if self.sending:
            return
        message = self.input_text.get("1.0", END).strip()
        if not message and not self.attachments:
            return
        model = self.model_var.get().strip()
        if not model:
            messagebox.showwarning("No model", "Pick a model first.")
            return

        user_msg = {"role": "user", "content": message}
        if self.attachments:
            user_msg["images"] = [a["base64"] for a in self.attachments]
        self.state["chat"].append(user_msg)
        self.save_state()
        self.render_chat()
        self.input_text.delete("1.0", END)
        self.current_response_text = ""
        self.last_prompt = message
        self.render_attachments()
        self.attachments = []
        bubble = self.add_chat_bubble("assistant", "Thinking…")
        self.sending = True
        self.status_var.set(f"Generating with {model}…")

        messages = []
        for msg in self.state["chat"]:
            entry = {"role": msg["role"], "content": msg.get("content", "")}
            if msg.get("images"):
                entry["images"] = msg["images"]
            messages.append(entry)

        def worker():
            try:
                with requests.post(f"{OLLAMA_API}/chat", json={
                    "model": model,
                    "messages": messages,
                    "stream": True,
                    "keep_alive": "2h",
                    "options": {"num_predict": 2200 if self.version_var.get() == "Jarvas Coding" else 1200}
                }, stream=True, timeout=1200) as res:
                    res.raise_for_status()
                    assistant_text = ""
                    for line in res.iter_lines():
                        if not line:
                            continue
                        part = json.loads(line.decode("utf-8"))
                        if part.get("error"):
                            raise RuntimeError(part["error"])
                        content = (((part.get("message") or {}).get("content")) or "")
                        if content:
                            assistant_text += content
                            self.pending_queue.put(("stream", assistant_text, bubble))
                    self.pending_queue.put(("done", assistant_text))
            except Exception as exc:
                self.pending_queue.put(("send_error", str(exc), bubble))
        threading.Thread(target=worker, daemon=True).start()

    def use_last_ai_code(self):
        text = self.last_assistant_text
        if not text.strip():
            messagebox.showinfo("No AI code", "No assistant response available yet.")
            return
        blocks = parse_code_blocks(text)
        files = self.state["workspace"]["files"]
        if not blocks:
            # create a notes file
            files["notes.md"] = text
        else:
            existing = set(files.keys())
            for block in blocks:
                filename = block["filename"] or default_filename_from_language(block["language"], existing)
                existing.add(filename)
                files[filename] = block["content"]
                self.selected_file = filename
        self.refresh_file_list()
        self.load_active_file()
        self.save_state()
        messagebox.showinfo("Added to Files", "Latest AI code was added to Project Files.")

    def refresh_file_list(self):
        self.file_list.delete(0, END)
        for name in self.state["workspace"]["files"].keys():
            self.file_list.insert(END, name)
        if self.selected_file in self.state["workspace"]["files"]:
            idx = list(self.state["workspace"]["files"].keys()).index(self.selected_file)
            self.file_list.selection_set(idx)

    def on_file_select(self, *_):
        sel = self.file_list.curselection()
        if not sel:
            return
        self.save_editor_to_state()
        self.selected_file = self.file_list.get(sel[0])
        self.load_active_file()
        self.save_state()

    def load_active_file(self):
        content = self.state["workspace"]["files"].get(self.selected_file, "")
        self.editor.delete("1.0", END)
        self.editor.insert("1.0", content)

    def save_editor_to_state(self):
        if not self.selected_file:
            return
        self.state["workspace"]["files"][self.selected_file] = self.editor.get("1.0", END).rstrip()
        self.save_state()

    def prompt_string(self, title, initial=""):
        win = Tk()
        win.withdraw()
        # use simple dialog fallback
        from tkinter.simpledialog import askstring
        val = askstring(APP_NAME, title, initialvalue=initial, parent=self.root)
        try:
            win.destroy()
        except Exception:
            pass
        return val

    def new_file(self):
        name = self.prompt_string("New filename:", "new_file.txt")
        if not name:
            return
        if name in self.state["workspace"]["files"]:
            messagebox.showwarning("Exists", "That file already exists.")
            return
        self.save_editor_to_state()
        self.state["workspace"]["files"][name] = ""
        self.selected_file = name
        self.refresh_file_list()
        self.load_active_file()
        self.save_state()

    def rename_file(self):
        if not self.selected_file:
            return
        new_name = self.prompt_string("Rename file:", self.selected_file)
        if not new_name or new_name == self.selected_file:
            return
        files = self.state["workspace"]["files"]
        if new_name in files:
            messagebox.showwarning("Exists", "That filename already exists.")
            return
        self.save_editor_to_state()
        files[new_name] = files.pop(self.selected_file)
        self.selected_file = new_name
        self.refresh_file_list()
        self.load_active_file()
        self.save_state()

    def delete_file(self):
        if not self.selected_file:
            return
        if not messagebox.askyesno("Delete file", f"Delete {self.selected_file}?"):
            return
        files = self.state["workspace"]["files"]
        files.pop(self.selected_file, None)
        self.selected_file = next(iter(files.keys()), "")
        self.refresh_file_list()
        self.load_active_file()
        self.save_state()

    def preview_workspace(self):
        self.save_editor_to_state()
        tmp_dir = Path(tempfile.mkdtemp(prefix="jarvas_preview_"))
        files = self.state["workspace"]["files"]
        for name, content in files.items():
            path = tmp_dir / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content, "utf-8")
        index = tmp_dir / ("index.html" if "index.html" in files else self.selected_file)
        if not index.exists():
            index = tmp_dir / self.selected_file
        try:
            webbrowser.open(index.as_uri())
        except Exception as exc:
            messagebox.showerror("Preview failed", str(exc))

    def export_workspace(self):
        self.save_editor_to_state()
        default_name = "jarvas_project.zip"
        save_path = filedialog.asksaveasfilename(title="Export project ZIP", defaultextension=".zip", initialfile=default_name, filetypes=[("ZIP", "*.zip")])
        if not save_path:
            return
        try:
            with zipfile.ZipFile(save_path, "w", zipfile.ZIP_DEFLATED) as zf:
                for name, content in self.state["workspace"]["files"].items():
                    zf.writestr(name, content)
            self.status_var.set(f"Exported project to {save_path}")
        except Exception as exc:
            messagebox.showerror("Export failed", str(exc))

    def _drain_queue(self):
        try:
            while True:
                item = self.pending_queue.get_nowait()
                kind = item[0]
                if kind == "models":
                    self.models = item[1]
                    self.version_model_map = map_models_to_versions(self.models)
                    chosen = self.state.get("selected_model") or self.version_model_map.get(self.version_var.get(), "")
                    self.model_combo["values"] = self.models
                    if chosen:
                        self.model_var.set(chosen)
                    self.status_var.set(f"Ready. {len(self.models)} local model(s) found.")
                    loaded = (self.state.get("loaded_model") or "").replace("Loaded: ", "").strip()
                    if chosen and (loaded == chosen):
                        self.loaded_var.set(f"Loaded: {chosen}")
                    elif chosen and not self.auto_load_attempted:
                        self.auto_load_attempted = True
                        self.root.after(250, self.load_selected_model)
                elif kind == "error_status":
                    self.status_var.set(item[1])
                elif kind == "loaded":
                    self.loaded_var.set(f"Loaded: {item[1]}")
                    self.status_var.set("Model loaded.")
                    self.model_var.set(item[1])
                    self.save_state()
                elif kind == "stream":
                    assistant_text, bubble = item[1], item[2]
                    for child in bubble.master.winfo_children():
                        pass
                    # bubble is a Label widget
                    bubble.configure(text=assistant_text)
                    self.chat_canvas.yview_moveto(1.0)
                elif kind == "done":
                    assistant_text = item[1]
                    self.sending = False
                    self.last_assistant_text = assistant_text
                    self.state["chat"].append({"role": "assistant", "content": assistant_text})
                    self.status_var.set("Done.")
                    self.save_state()
                    self.render_chat()
                elif kind == "send_error":
                    self.sending = False
                    error_text = item[1]
                    self.status_var.set(f"Error: {error_text}")
                    self.state["chat"].append({"role": "assistant", "content": f"Could not generate a response. {error_text}", "error": True})
                    self.save_state()
                    self.render_chat()
        except queue.Empty:
            pass
        self.root.after(80, self._drain_queue)

def main():
    root = Tk()
    app = JarvasApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
